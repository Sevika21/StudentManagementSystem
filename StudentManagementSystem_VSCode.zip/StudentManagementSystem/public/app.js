const $=id=>document.getElementById(id);
let students=[];
async function api(method="GET",data=null){
 const opts={method,headers:{"Content-Type":"application/x-www-form-urlencoded"}};
 if(data) opts.body=new URLSearchParams(data).toString();
 const res=await fetch("/api/students",opts); const result=await res.json();
 if(!res.ok) throw new Error(result.error||"Request failed"); return result;
}
function toast(msg,error=false){const t=$("toast");t.textContent=msg;t.className="toast"+(error?" error":"");t.style.display="block";setTimeout(()=>t.style.display="none",2500)}
function statusCell(s){return `<span class="status ${s.status==="Inactive"?"inactive":""}">${s.status}</span>`}
function render(){
 $("total").textContent=students.length;
 $("active").textContent=students.filter(s=>s.status==="Active").length;
 $("inactive").textContent=students.filter(s=>s.status==="Inactive").length;
 $("recent").innerHTML=students.slice(-5).reverse().map(s=>`<tr><td>${s.id}</td><td>${safe(s.name)}</td><td>${safe(s.email)}</td><td>${safe(s.course)}</td><td>${statusCell(s)}</td></tr>`).join("");
 $("allRows").innerHTML=students.map(s=>`<tr><td>${s.id}</td><td>${safe(s.name)}</td><td>${safe(s.email)}</td><td>${safe(s.course)}</td><td>${statusCell(s)}</td><td><button class="smallbtn edit" onclick="editStudent(${s.id})">Edit</button><button class="smallbtn delete" onclick="deleteStudent(${s.id})">Delete</button></td></tr>`).join("");
}
function safe(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function load(){students=await api();render()}
function showPage(page){
 document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
 $(page).classList.remove("hidden");
 document.querySelectorAll(".nav[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
}
document.querySelectorAll(".nav[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$("logout").addEventListener("click",()=>{showPage("dashboard");toast("You are still in the demo session.")});
function resetForm(){ $("studentForm").reset();$("studentId").value="";$("formTitle").textContent="Add Student"; }
$("reset").addEventListener("click",resetForm);
$("studentForm").addEventListener("submit",async e=>{
 e.preventDefault();
 const data={name:$("name").value.trim(),email:$("email").value.trim(),course:$("course").value,status:$("status").value};
 try{
  if($("studentId").value){data.id=$("studentId").value;await api("PUT",data);toast("Student details updated successfully!")}
  else{await api("POST",data);toast("Student added successfully!")}
  await load();resetForm();showPage("students");
 }catch(err){toast(err.message,true)}
});
window.editStudent=id=>{
 const s=students.find(x=>x.id===id);if(!s)return;
 $("studentId").value=s.id;$("name").value=s.name;$("email").value=s.email;
 $("course").value=s.course;$("status").value=s.status;$("formTitle").textContent="Update Student";showPage("add");
};
window.deleteStudent=async id=>{
 if(!confirm("Are you sure you want to delete this student?"))return;
 try{await api("DELETE",{id});await load();toast("Student deleted successfully!")}catch(err){toast(err.message,true)}
};
$("searchBtn").addEventListener("click",filterRows);
$("search").addEventListener("input",filterRows);
$("showAll").addEventListener("click",()=>{$("search").value="";filterRows()});
function filterRows(){const q=$("search").value.toLowerCase();document.querySelectorAll("#allRows tr").forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?"":"none")}
load().catch(e=>toast(e.message,true));