STUDENT MANAGEMENT SYSTEM - VS CODE RUN STEPS

Requirements:
- JDK 17 or later
- Visual Studio Code

Folder structure:
StudentManagementSystem/
  src/Main.java
  public/index.html
  public/style.css
  public/app.js

Run:
1. Open the StudentManagementSystem folder in VS Code.
2. Open Terminal > New Terminal.
3. Compile:
   javac -d out src/Main.java
4. Start the server from the project folder:
   java -cp out Main
5. Open Chrome and visit:
   http://localhost:3000

Keep the terminal open while using the application.
The sample student records are loaded when the Java server starts.
Data is kept in memory and resets when the server is restarted.
