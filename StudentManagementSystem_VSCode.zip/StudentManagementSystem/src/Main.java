import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.Executors;

public class Main {
    private static final List<Student> students = new ArrayList<>();
    private static int nextId = 6;

    static class Student {
        int id; String name, email, course, status;
        Student(int id, String name, String email, String course, String status) {
            this.id=id; this.name=name; this.email=email; this.course=course; this.status=status;
        }
        String json() {
            return "{\"id\":"+id+",\"name\":\""+esc(name)+"\",\"email\":\""+esc(email)+
                   "\",\"course\":\""+esc(course)+"\",\"status\":\""+esc(status)+"\"}";
        }
    }
    static String esc(String s) { return s.replace("\\","\\\\").replace("\"","\\\""); }
    static void send(HttpExchange ex, int status, String body, String type) throws IOException {
        byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", type+"; charset=UTF-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin","*");
        ex.sendResponseHeaders(status,bytes.length);
        try(OutputStream os=ex.getResponseBody()){ os.write(bytes); }
    }
    static Map<String,String> params(HttpExchange ex) throws IOException {
        String body=new String(ex.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);
        Map<String,String> map=new HashMap<>();
        for(String pair:body.split("&")) {
            if(pair.isEmpty()) continue;
            String[] p=pair.split("=",2);
            map.put(URLDecoder.decode(p[0],StandardCharsets.UTF_8),
                    p.length>1?URLDecoder.decode(p[1],StandardCharsets.UTF_8):"");
        }
        return map;
    }
    static String studentsJson() {
        StringJoiner j=new StringJoiner(",","[","]");
        for(Student s:students) j.add(s.json());
        return j.toString();
    }
    public static void main(String[] args) throws Exception {
        students.add(new Student(1,"Lekya Dosakayala","lekya1@gmail.com","CSE","Active"));
        students.add(new Student(2,"Sruthi Reddy","sruthi@gmail.com","CSE","Active"));
        students.add(new Student(3,"Anjali Sharma","anjali@gmail.com","ECE","Active"));
        students.add(new Student(4,"Keerthi Reddy","keerthi@gmail.com","CSE","Active"));
        students.add(new Student(5,"Sneha Patel","sneha@gmail.com","ECE","Inactive"));

        HttpServer server=HttpServer.create(new InetSocketAddress(3000),0);
        server.createContext("/api/students", ex -> {
            try {
                String method=ex.getRequestMethod();
                if(method.equals("GET")) { send(ex,200,studentsJson(),"application/json"); return; }
                if(method.equals("OPTIONS")) { send(ex,204,"","text/plain"); return; }
                Map<String,String> p=params(ex);
                if(method.equals("POST")) {
                    String name=p.getOrDefault("name","").trim(), email=p.getOrDefault("email","").trim();
                    String course=p.getOrDefault("course",""), status=p.getOrDefault("status","Active");
                    if(name.isEmpty() || !email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                        send(ex,400,"{\"error\":\"Enter a name and valid email address.\"}","application/json"); return;
                    }
                    Student s=new Student(nextId++,name,email,course,status); students.add(s);
                    send(ex,201,s.json(),"application/json"); return;
                }
                if(method.equals("PUT")) {
                    int id=Integer.parseInt(p.getOrDefault("id","0"));
                    for(Student s:students) if(s.id==id) {
                        s.name=p.getOrDefault("name",s.name); s.email=p.getOrDefault("email",s.email);
                        s.course=p.getOrDefault("course",s.course); s.status=p.getOrDefault("status",s.status);
                        send(ex,200,s.json(),"application/json"); return;
                    }
                    send(ex,404,"{\"error\":\"Student not found.\"}","application/json"); return;
                }
                if(method.equals("DELETE")) {
                    int id=Integer.parseInt(p.getOrDefault("id","0"));
                    boolean removed=students.removeIf(s->s.id==id);
                    send(ex,removed?200:404,removed?"{\"message\":\"Deleted\"}":"{\"error\":\"Student not found\"}","application/json"); return;
                }
                send(ex,405,"{\"error\":\"Method not allowed\"}","application/json");
            } catch(Exception e) { send(ex,500,"{\"error\":\"Server error\"}","application/json"); }
        });
        server.createContext("/", ex -> {
            String path=ex.getRequestURI().getPath();
            if(path.equals("/")) path="/index.html";
            Path file=Path.of("public",path.substring(1)).normalize();
            if(!file.startsWith(Path.of("public")) || !Files.exists(file) || Files.isDirectory(file)) {
                send(ex,404,"Not found","text/plain"); return;
            }
            String type=path.endsWith(".css")?"text/css":path.endsWith(".js")?"application/javascript":"text/html";
            send(ex,200,Files.readString(file),"".equals(type)?"text/plain":type);
        });
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();
        System.out.println("Student Management System is running.");
        System.out.println("Open your browser: http://localhost:3000");
    }
}
